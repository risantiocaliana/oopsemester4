/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package latihan1;

/**
 *
 * @author Nanda
 * TGL : 2024-03-18
 */
public class Latihan2 {
    /*
    Method: Cetak
    digunakan untuk menampilkan teks 'apa saja ya?'
    */
    public void cetak(){
        System.out.println("          ／＞　　 フ\n"+
"　　　 　　| 　_　 _ |\n" +
"　 　　 　／` ミ＿xノ\n" +
"　　 　 /　　　 　 |\n" +
"　　　 /　 ヽ　　 ﾉ\n" +
"　 　 │　　|　|　|\n" +
"　／￣|　　 |　|　|\n" +
"　| (￣ヽ＿_ヽ_)__)\n" +
"　＼二つ");
    }
    
    /*
    Method: cetak(str)
    digunakan untuk menampilkan teks dari str
    In: str String
    */
    public void cetak(String str){
        System.out.println(str);
    }
}
